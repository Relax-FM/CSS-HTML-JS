var tileSources = [
    'photo.dzi'
];
OpenSeadragon({
	id: 'openseadragon1',
	prefixUrl: '/5 - openseaDragon/images/',
	tileSources: tileSources,
})